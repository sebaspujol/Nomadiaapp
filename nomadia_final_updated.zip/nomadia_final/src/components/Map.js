'use client'
import { useEffect, useRef, useState } from 'react'
import styles from './Map.module.css'

const TYPE_COLORS = {
  cafe: '#F0A93E',
  cowork: '#0F9D6E',
  hotel: '#3B82F6',
  biblioteca: '#C0574F',
}

const LEGEND = [
  { tipo: 'cafe', label: 'Cafés' },
  { tipo: 'cowork', label: 'Coworks' },
  { tipo: 'hotel', label: 'Hoteles' },
  { tipo: 'biblioteca', label: 'Bibliotecas' },
]

function pinLabel(place) {
  if (!place.verified) return place.precio || 'Sin verificar'
  if (place.rating) return `★${place.rating}`
  if (place.gratis) return 'Gratis'
  return place.precio || ''
}

export default function Map({ places, selected, onSelect, userLocation, loading }) {
  const mapRef = useRef(null)
  const mapInstance = useRef(null)
  const markers = useRef([])
  const userMarker = useRef(null)
  const [mapsLoaded, setMapsLoaded] = useState(false)

  // Cargar Google Maps script
  useEffect(() => {
    if (window.google) { setMapsLoaded(true); return }
    const key = process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY
    if (!key) { setMapsLoaded(false); return }

    const script = document.createElement('script')
    script.src = `https://maps.googleapis.com/maps/api/js?key=${key}&libraries=places`
    script.async = true
    script.onload = () => setMapsLoaded(true)
    document.head.appendChild(script)
  }, [])

  // Inicializar mapa
  useEffect(() => {
    if (!mapsLoaded || !mapRef.current || mapInstance.current) return
    mapInstance.current = new window.google.maps.Map(mapRef.current, {
      center: userLocation,
      zoom: 14,
      disableDefaultUI: true,
      zoomControl: false,
      styles: mapStyles,
    })
  }, [mapsLoaded, userLocation])

  // Marcador de usuario
  useEffect(() => {
    if (!mapInstance.current || !mapsLoaded) return
    if (userMarker.current) userMarker.current.setMap(null)
    userMarker.current = new window.google.maps.Marker({
      position: userLocation,
      map: mapInstance.current,
      icon: {
        path: window.google.maps.SymbolPath.CIRCLE,
        scale: 8,
        fillColor: '#3B82F6',
        fillOpacity: 1,
        strokeColor: '#fff',
        strokeWeight: 3,
      },
      title: 'Tu ubicación',
      zIndex: 999,
    })
  }, [userLocation, mapsLoaded])

  // Markers de lugares
  useEffect(() => {
    if (!mapInstance.current || !mapsLoaded) return
    markers.current.forEach(m => m.setMap(null))
    markers.current = []

    places.forEach(place => {
      const color = place.verified === false ? '#fff' : (TYPE_COLORS[place.tipo] || '#888')
      const label = pinLabel(place)

      const marker = new window.google.maps.Marker({
        position: { lat: place.lat, lng: place.lng },
        map: mapInstance.current,
        title: place.nombre,
        icon: {
          url: `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
            <svg xmlns="http://www.w3.org/2000/svg" width="120" height="34" viewBox="0 0 120 34">
              <rect x="1" y="1" width="118" height="32" rx="16" fill="${place.verified === false ? '#fff' : '#111827'}" stroke="${place.verified === false ? '#EAE8E3' : 'none'}" stroke-width="1.5"/>
              <circle cx="20" cy="17" r="5" fill="${color}"/>
              <text x="34" y="22" font-family="JetBrains Mono, monospace" font-size="13" font-weight="700" fill="${place.verified === false ? '#6B7280' : '#fff'}">${label}</text>
            </svg>
          `)}`,
          scaledSize: new window.google.maps.Size(120, 34),
          anchor: new window.google.maps.Point(20, 34),
        },
      })

      marker.addListener('click', () => onSelect(place))
      markers.current.push(marker)
    })
  }, [places, mapsLoaded])

  // Centrar en seleccionado
  useEffect(() => {
    if (selected && mapInstance.current) {
      mapInstance.current.panTo({ lat: selected.lat, lng: selected.lng })
    }
  }, [selected])

  const zoomBy = (delta) => {
    if (!mapInstance.current) return
    mapInstance.current.setZoom((mapInstance.current.getZoom() || 14) + delta)
  }

  // Fallback sin API key: mapa estático SVG
  if (!process.env.NEXT_PUBLIC_GOOGLE_MAPS_KEY) {
    return <StaticMap places={places} selected={selected} onSelect={onSelect} userLocation={userLocation} loading={loading} />
  }

  return (
    <div className={styles.mapPane}>
      {loading && <div className={styles.loading}>Cargando lugares...</div>}
      <div ref={mapRef} className={styles.map} />
      <div className={styles.legend}>
        {LEGEND.map(l => (
          <div key={l.tipo}><span className={styles.catDot} style={{ background: TYPE_COLORS[l.tipo] }} />{l.label}</div>
        ))}
      </div>
      <div className={styles.zoomCtl}>
        <button onClick={() => zoomBy(1)}>+</button>
        <button onClick={() => zoomBy(-1)}>−</button>
      </div>
    </div>
  )
}

// Mapa estático SVG para demo sin API key
function StaticMap({ places, selected, onSelect, loading }) {
  // Posiciones hardcodeadas para el demo, distribuidas en el lienzo del mapa
  const positions = {
    '1': { left: 22, top: 30 }, '2': { left: 42, top: 46 },
    '3': { left: 27, top: 63 }, '4': { left: 69, top: 41 },
    '5': { left: 84, top: 70 }, '6': { left: 57, top: 19 },
    '7': { left: 79, top: 61 },
  }
  const fallbackPositions = [
    { left: 30, top: 28 }, { left: 46, top: 44 }, { left: 62, top: 32 },
    { left: 38, top: 60 }, { left: 70, top: 55 }, { left: 22, top: 48 },
  ]

  return (
    <div className={styles.mapPane}>
      {loading && <div className={styles.loading}>Cargando lugares...</div>}
      <svg className={styles.bg} viewBox="0 0 900 700" preserveAspectRatio="xMidYMid slice">
        <rect width="900" height="700" fill="#EEF0EA" />
        <g opacity=".55" fill="#DEE1D6">
          <rect x="80" y="60" width="140" height="90" rx="10" /><rect x="260" y="40" width="100" height="70" rx="10" />
          <rect x="400" y="70" width="160" height="100" rx="10" /><rect x="600" y="50" width="120" height="80" rx="10" />
          <rect x="100" y="220" width="150" height="100" rx="10" /><rect x="300" y="240" width="110" height="80" rx="10" />
          <rect x="480" y="220" width="170" height="110" rx="10" /><rect x="700" y="240" width="130" height="90" rx="10" />
          <rect x="80" y="400" width="140" height="100" rx="10" /><rect x="280" y="410" width="160" height="90" rx="10" />
          <rect x="500" y="390" width="130" height="110" rx="10" /><rect x="680" y="410" width="150" height="90" rx="10" />
        </g>
        <path d="M0,350 Q450,300 900,380" stroke="#F8F8F4" strokeWidth="20" fill="none" />
        <path d="M300,0 Q380,350 320,700" stroke="#F8F8F4" strokeWidth="16" fill="none" />
        <ellipse cx="720" cy="560" rx="80" ry="46" fill="#CFE0C0" />
      </svg>
      <div className={styles.userDot} />
      {places.map((p, i) => {
        const pos = positions[p.id] || fallbackPositions[i % fallbackPositions.length]
        const isSelected = selected?.id === p.id
        const color = p.verified === false ? '#3B82F6' : (TYPE_COLORS[p.tipo] || '#888')
        return (
          <div
            key={p.id}
            className={`${styles.pin} ${isSelected ? styles.active : ''} ${p.verified === false ? styles.unverified : ''}`}
            style={{ left: `${pos.left}%`, top: `${pos.top}%` }}
            onClick={() => onSelect(p)}
          >
            <div className={styles.bubble}>
              <span className={styles.catDot} style={{ background: color }} />
              {pinLabel(p)}
            </div>
          </div>
        )
      })}
      <div className={styles.legend}>
        {LEGEND.map(l => (
          <div key={l.tipo}><span className={styles.catDot} style={{ background: TYPE_COLORS[l.tipo] }} />{l.label}</div>
        ))}
      </div>
      <div className={styles.zoomCtl}>
        <button>+</button>
        <button>−</button>
      </div>
    </div>
  )
}

const mapStyles = [
  { elementType: 'geometry', stylers: [{ color: '#EEF0EA' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#6B7280' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#F8F8F4' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#F8F8F4' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#EAE8E3' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#F0ECE6' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#DCE7F5' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#CFE0C0' }] },
  { featureType: 'poi', elementType: 'labels', stylers: [{ visibility: 'off' }] },
  { featureType: 'transit', stylers: [{ visibility: 'off' }] },
  { featureType: 'administrative', elementType: 'geometry', stylers: [{ visibility: 'off' }] },
  { featureType: 'building', elementType: 'geometry', stylers: [{ color: '#DEE1D6' }] },
]
