# Nomadia 🗺️
### Encontrá tu espacio de trabajo ideal, en cualquier ciudad

---

## Deploy completo en ~30 minutos (sin saber programar)

Necesitás crear 4 cuentas gratuitas: GitHub, Supabase, Google Cloud, Vercel.

---

## PASO 1 — GitHub (subir el código)

1. Entrá a github.com → creá cuenta → verificá el email
2. Hacé clic en "New repository" → nombre: nomadia · Private → "Create repository"
3. Tocá "uploading an existing file" → arrastrá TODOS los archivos del ZIP → "Commit changes"

---

## PASO 2 — Base de datos con Supabase (gratis)

1. Entrá a supabase.com → "Start your project" → creá cuenta con GitHub
2. "New project" → nombre: nomadia → región: West EU (Ireland) → generá contraseña (guardala)
3. Esperá ~2 minutos
4. Settings → Database → Connection string → URI → copiá ese string

---

## PASO 3 — Google Cloud (Maps, Places, Geocoding, OAuth)

### APIs
1. console.cloud.google.com → New Project → nombre: nomadia
2. APIs & Services → Library → activá: **Maps JavaScript API** + **Places API** + **Geocoding API** (la Geocoding API es nueva: se usa para ubicar locales a partir de su dirección y para el buscador de ciudad)
3. Credentials → Create Credentials → API Key → copiá (empieza con AIza...)
4. Antes de invitar gente a probar la app, restringí esa key por HTTP referrer a tu dominio (evita que alguien más la use con tu cuota).

### OAuth para Gmail
1. Credentials → Create Credentials → OAuth 2.0 Client ID → Web application
2. Authorized redirect URIs: https://TU-APP.vercel.app/api/auth/callback/google
3. Copiá Client ID y Client Secret

---

## PASO 4 — Deploy en Vercel

1. vercel.com → Sign up con GitHub → New Project → repo nomadia → Import
2. Environment Variables — agregá estas:

DATABASE_URL          = string de Supabase
NEXTAUTH_SECRET       = cualquier texto largo random
NEXTAUTH_URL          = https://nomadia.vercel.app
GOOGLE_CLIENT_ID      = del paso 3b
GOOGLE_CLIENT_SECRET  = del paso 3b
GOOGLE_PLACES_API_KEY = del paso 3a
NEXT_PUBLIC_GOOGLE_MAPS_KEY = misma que arriba
ANTHROPIC_API_KEY     = de platform.anthropic.com
ADMIN_EMAILS          = spujol@riamoneytransfer.com (tu email de login, separá con comas si sumás más admins)

3. Deploy → en 2-3 minutos tenés URL tipo nomadia.vercel.app

### Paso 4b — Crear tablas en la base de datos
En tu computadora: instalá Node.js → abrí la carpeta del proyecto → corré:

```
npm install
npx prisma db push
```

### Paso 4c — Precargar Madrid y Buenos Aires (para el lanzamiento friends & family)
El resto del mundo se carga solo, la primera vez que alguien busca esa zona (import bajo demanda
desde Google Places). Para que Madrid y Buenos Aires ya tengan datos desde el primer día, corré
localmente (con tu `.env.local` configurado con las mismas variables de arriba):

```
npm run seed:madrid
npm run seed:buenosaires
```

---

## PASO 5 — Tu dashboard de métricas

Una vez logueado en la app con el mismo email que pusiste en `ADMIN_EMAILS`, vas a ver un ícono
extra al lado de tu avatar (arriba a la derecha) que te lleva a `/admin`. Ahí ves: usuarios nuevos
(totales, últimos 7 y 30 días), locales nuevos, check-ins activos ahora mismo, reviews, puntos
otorgados en total, un top 10 de locales mejor puntuados, tus usuarios más activos, y el desglose
de locales por tipo / origen (Google vs. comunidad) / ciudad. Nadie más que los emails en
`ADMIN_EMAILS` puede entrar ahí, aunque conozcan la URL.

Si en algún momento querés sumar a alguien más de tu equipo, agregale el email a la variable
`ADMIN_EMAILS` en Vercel (Project → Settings → Environment Variables) separado por comas y
redeployá.

---

## Cómo subir cambios después del primer deploy

Una vez que ya hiciste el deploy inicial (pasos 1 a 4), subir una actualización — como esta, con
el dashboard nuevo — es mucho más simple, no hace falta repetir todo:

1. Bajá el ZIP nuevo que te mandé y descomprimilo.
2. Entrá a tu repo en GitHub → arrastrá y reemplazá los archivos que cambiaron (o subí la carpeta
   entera de nuevo con "uploading an existing file", GitHub sobreescribe los que ya existían) →
   "Commit changes".
3. Si esta actualización agrega una variable de entorno nueva (como `ADMIN_EMAILS` en este caso),
   sumala en Vercel → tu proyecto → Settings → Environment Variables antes de que vuelva a
   compilar, o el deploy va a fallar.
4. Vercel detecta el cambio en GitHub solo y arranca el redeploy automáticamente — en 2-3 minutos
   está en producción. Lo podés seguir en la pestaña "Deployments" de tu proyecto en Vercel.
5. Si la actualización cambió `prisma/schema.prisma` (agregó una tabla o un campo nuevo), corré
   una vez más, en tu computadora:
   ```
   npx prisma db push
   ```
   Esta versión no tocó el schema, así que este paso no hace falta para el dashboard.

Con este flujo no necesitás volver a crear cuentas ni repetir los pasos 2 y 3 — Supabase y Google
Cloud quedan tal cual, solo actualizás el código en GitHub.

---

## Qué cambió en esta versión

- Check-in y reviews son reales (antes eran solo estado del navegador, se perdían al refrescar).
- Las reviews puntúan 6 factores por separado (comodidad, silencio y concentración, enchufes,
  conectividad, servicio, comida) más tiempo máximo y consumo mínimo — no un genérico de estrellas.
- El mapa de descubrimiento lee tu propia base de datos, combinada con un import automático de
  Google Places para zonas sin datos todavía (marcadas como "Sin verificación" hasta que alguien
  deje la primera review real).
- Sistema de puntos (0.25 por check-in, 1 por review, tope de 2 por día, sin poder repetir puntos
  en el mismo local antes de 14 días) — el saldo se guarda desde ya, aunque todavía no hay canjes
  con partners.
- El menú escaneado con IA ahora se guarda de verdad y muestra la fecha de última actualización.
- No existe un rol de "dueño de local": es una sola cuenta para todos. Cualquier usuario logueado
  puede sumar un lugar que falte (botón "+ Añadir lugar") y, una vez que hizo check-in real ahí,
  puede dejar su review, escanear/actualizar el menú y subir una foto de portada — exactamente
  igual que cualquier otro miembro de la comunidad.
- Las fotos de portada salen de Google Places para los locales importados, o de la primera foto
  que alguien suba junto a su review para los locales cargados por la comunidad.
- Look and feel rediseñado por completo (tipografías Plus Jakarta Sans / JetBrains Mono, acento
  verde, mapa con pines tipo burbuja y leyenda de categorías, tarjetas con foto/rating/tipo de lugar).
- Nuevo dashboard de métricas en `/admin` (solo visible para los emails en `ADMIN_EMAILS`): usuarios
  y locales nuevos por día, check-ins activos, reviews, puntos otorgados, top de locales mejor
  puntuados, usuarios más activos, y desgloses por tipo de local / origen / ciudad.

---

## Stack
Next.js 14 · Prisma · PostgreSQL (Supabase) · NextAuth · Google Maps/Places/Geocoding · Claude API · Vercel
